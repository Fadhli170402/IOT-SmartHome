<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Cam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
    <style>
        .main-container {
            display: flex;
            flex-wrap: wrap
        }
        .main-container .video-block {
            padding: 40px;
            width: 100%;
            max-width: 768px;
            min-width: 300px
        }
        .main-container .cmd-block {
            padding: 40px;
            min-width: 300px
        }

        footer {
        width: 100%;
        height: 50px;
        padding-left: 10px;
        line-height: 50px;
        background: #333;
        color: #fff;
        position: fixed;
        bottom: 0px;
        text-align: center;
        left: 0;
        bottom: 0;
        }
    </style>

  <body>
    <div>
        <nav class="navbar navbar-expand-lg" style="background-color:#0B3C5D">
            <div class="container-fluid">
                <a class="navbar-brand" href="#" style="color:#ffffff; font-size:18pt"><img src="../img/logo.png"  alt="Logo Security Cam" width="50px" height="50px">Security Cam</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </nav>
    </div>
    
    <div class="card text-center">
        <div class="card-body main-container justify-content-center align-item-center">
            <div>
                <div class="video-block">
                    <!-- <img src='http://192.168.38.184/mjpeg/1' alt="Video stream" style="object-fit: contain; height: 100%; width: 100%; background-color: #353535"/><br><br> -->
                    <img id="image1" src="/img/No Camera.jpg" alt="No Camera" style="object-fit: contain; height: 100%; width: 100%; background-color: #353535"><br><br>
                    <div class="main-container justify-content-center align-item-center">
                        <button type="button" class="btn btn-primary btn-lg" style="margin-right: 20px;" onClick="changeImage1()">On Camera</button>
                        <button type="button" class="btn btn-danger btn-lg" style="margin-left: 20px;" onClick="changeImage2()">Off Camera</button>
                    </div>  
                    <script>
                        function changeImage1() {
                            var img = document.getElementById('image1');
                            img.src = 'http://192.168.38.184/mjpeg/1';
                        }

                        function changeImage2() {
                            var img = document.getElementById('image1');
                            img.src = 'img/No Camera.jpg';
                        }
                    </script>
                    <br><br>
                    
                    <form>
                        <div class="form-group">
                            <label for="customRange1" class="form-label">Rotate (Up and Down)</label>
                            <input type="range" class="form-range" id="customRange1">
                        </div>
                        <div class="form-group">
                            <label for="customRange1" class="form-label">Rotate (Left and Right)</label>
                            <input type="range" class="form-range" id="customRange1">
                        </div>
                    </form>
                </div>
            </div>
        </div>
      
        <div class="card-footer text-muted">
            <p>Created by Group 5</p> 
            <p>End of the Line</p>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\laragon\www\pem-iot-cam-security\resources\views////screen/HomePage.blade.php ENDPATH**/ ?>