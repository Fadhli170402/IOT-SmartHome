<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Cam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
    <style>
        .main-container {
            display: flex;
            flex-wrap: wrap
        }
        .main-container .video-block {
            padding: 40px;
            width: 100%;
            max-width: 768px;
            min-width: 300px
        }
        .main-container .cmd-block {
            padding: 40px;
            min-width: 300px
        }

        footer {
        width: 100%;
        height: 50px;
        padding-left: 10px;
        line-height: 50px;
        background: #333;
        color: #fff;
        position: fixed;
        bottom: 0px;
        text-align: center;
        left: 0;
        bottom: 0;
        }
    </style>

  <body>
    <div>
        <nav class="navbar navbar-expand-lg" style="background-color:#0B3C5D">
            <div class="container-fluid">
                <a class="navbar-brand" href="#" style="color:#ffffff; font-size:18pt"><img src="../img/logo.png"  alt="Logo Security Cam" width="50px" height="50px">Security Cam</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </nav>
    </div>
    
    <div class="card text-center">
        <div class="card-body main-container justify-content-center align-item-center">
            <div>
                <div class="video-block">
                    <!-- <img src='http://192.168.38.184/mjpeg/1' alt="Video stream" style="object-fit: contain; height: 100%; width: 100%; background-color: #353535"/><br><br> -->
                    <img id="image1" src="/img/No Camera.jpg" alt="No Camera" style="object-fit: contain; height: 100%; width: 100%; background-color: #353535"><br><br>
                    <div class="main-container justify-content-center align-item-center">
                        <button type="button" class="btn btn-primary btn-lg" style="margin-right: 20px;" onClick="changeImage1()">On Camera</button>
                        <button type="button" class="btn btn-danger btn-lg" style="margin-left: 20px;" onClick="changeImage2()">Off Camera</button>
                    </div>  
                    <script>
                        function changeImage1() {
                            var img = document.getElementById('image1');
                            img.src = 'http://192.168.38.184/mjpeg/1';
                        }

                        function changeImage2() {
                            var img = document.getElementById('image1');
                            img.src = 'img/No Camera.jpg';
                        }
                    </script>
                    <br><br>
                    
                    <!-- <form>
                        <div class="form-group">
                            <label for="slider" class="form-label">Rotate (Up and Down)</label>
                            <input type="range" class="form-range" min="40" max="150" value="95" id="slider">
                            <div id="SelectValue"></div>
                        </div>
                        <br><br>
                        <div class="form-group">
                            <label for="slider2" class="form-label">Rotate (Left and Right)</label>
                            <input type="range" class="form-range" min="0" max="180" value="90" id="slider2">
                            <div id="SelectValue2"></div>
                        </div>
                    </form> -->

                    <form>
                        <div class="form-group">
                            <label for="slider" id="message"class="form-label">Rotate (Up and Down)</label>
                            <input type="range" id="value1" class="form-range" data-slider-min="40" data-slider-max="150" data-slider-step="1" data-slider-value="90"  data-slider-selection="after" data-slider-tooltip="hide">
                            <div id="SelectValue"></div>
                        </div>
                        <br><br>
                        <div class="form-group">
                            <label for="slider2"   class="form-label">Rotate (Left and Right)</label>
                            <input type="range" id="value2" class="form-range" data-slider-min="0" data-slider-max="180" data-slider-step="1" data-slider-value="90"  data-slider-selection="after" data-slider-tooltip="hide">
                            <div id="SelectValue2"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      
        <div class="card-footer text-muted">
            <p>Created by Group 5</p> 
            <p>End of the Line</p>
        </div>
    </div>

    <script>
        var slider = document.getElementById("value1");
        var SelectValue = document.getElementById("SelectValue");

        SelectValue.innetHTML = slider.value;

        slider.oninput = function() {
            SelectValue.innerHTML = this.value;

        }
    </script>
    <script>
        var slider2 = document.getElementById("value2");
        var SelectValue2 = document.getElementById("SelectValue2");

        SelectValue2.innetHTML = slider2.value;

        slider2.oninput = function() {
            SelectValue2.innerHTML = this.value;
        }
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/paho-mqtt/1.0.1/mqttws31.js" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.6.3.js" 
                integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
    <script>
        client = new Paho.MQTT.Client("localhost", 8083, "clientId");
        client.onConnectionLost = onConnectionLost;
        client.connect({
            onSuccess : onConnect
        });
        function onConnect(){
            console.log("OnConnect");
        }
        function onConnectionLost(responseObject){
            if(responseObject.errorCode !==0){
                console.log("OnConnectionLost: "+ responseObject.errorMessage);
            }
        }
        // $("SelectValue").onchange(function(){
        //     var msg =$('#value1').val();
        //     message = new Paho.MQTT.Message(msg);
        //     message.destinationName = "test";
        //     client.send(message);
        // });
        $(function() {
            $('#value1').on('change', function (ev) {
            console.log($('#value1').val());
            var msg =$('#value1').val();
            message = new Paho.MQTT.Message(msg);
            message.destinationName = "test";
            client.send(message);
            console.log(message);

        });        
        });
        $(function() {
            $('#value2').on('change', function (ev) {
            console.log($('#value2').val());
            var msg =$('#value2').val();
            message = new Paho.MQTT.Message(msg);
            message.destinationName = "test2";
            client.send(message);
            console.log(message);

        });        
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  </body>
</html>